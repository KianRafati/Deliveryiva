package src;
class Main{
    public static void main(String[] args) {
        PageHandler.showPage();
    } 
}