package src;

public class Edge {

}
