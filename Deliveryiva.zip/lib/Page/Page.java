package lib.Page;

public abstract class Page {
    public Page previousPage = null;
    abstract public void run(String input);
}
