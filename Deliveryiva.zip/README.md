# Deliveryiva
An application similar to Uber Eats and Snapp food.

======================================================

Kian Rafati Sajedi  Student ID: 401107913

AmirParsa Bahrami   Student ID: 401101332

Sahar Semsarha      Student ID: 401101879
