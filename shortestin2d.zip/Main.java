import java.util.*;
import java.util.function.ToIntFunction;

public class Main {
    private static final int INF = Integer.MAX_VALUE;

    public static List<Integer> findShortestPath(int[][] graph, int startNode, int endNode) {
        int numNodes = graph.length;
        int[] distances = new int[numNodes];
        boolean[] visited = new boolean[numNodes];
        int[] previous = new int[numNodes];

        Arrays.fill(distances, INF);
        Arrays.fill(previous, -1);

        distances[startNode] = 0;

        PriorityQueue<Node> queue = new PriorityQueue<Node>(Comparator.comparingInt(new ToIntFunction<Object>() {
            @Override
            public int applyAsInt(Object node) {
                return node.distance;
            }
        }));
        queue.add(new Node(startNode, 0));

        while (!queue.isEmpty()) {
            Node currentNode = queue.poll();
            int nodeIndex = currentNode.index;
            visited[nodeIndex] = true;

            if (nodeIndex == endNode) {
                break;
            }

            for (int neighbor = 0; neighbor < numNodes; neighbor++) {
                int weight = graph[nodeIndex][neighbor];
                if (weight > 0 && !visited[neighbor]) {
                    int distance = distances[nodeIndex] + weight;
                    if (distance < distances[neighbor]) {
                        distances[neighbor] = distance;
                        previous[neighbor] = nodeIndex;
                        queue.add(new Node(neighbor, distance));
                    }
                }
            }
        }

        List<Integer> shortestPath = new ArrayList<Integer>();
        int currentNode = endNode;
        while (currentNode != -1) {
            shortestPath.add(0, currentNode);
            currentNode = previous[currentNode];
        }

        return shortestPath;
    }

    private static class Node {
        private int index;
        private int distance;

        public Node(int index, int distance) {
            this.index = index;
            this.distance = distance;
        }
    }

    public static void main(String[] args) {
        int[][] graph = {
                {0, 4, 0, 0, 0, 0, 0, 8, 0},
                {4, 0, 8, 0, 0, 0, 0, 11, 0},
                {0, 8, 0, 7, 0, 4, 0, 0, 2},
                {0, 0, 7, 0, 9, 14, 0, 0, 0},
                {0, 0, 0, 9, 0, 10, 0, 0, 0},
                {0, 0, 4, 14, 10, 0, 2, 0, 0},
                {0, 0, 0, 0, 0, 2, 0, 1, 6},
                {8, 11, 0, 0, 0, 0, 1, 0, 7},
                {0, 0, 2, 0, 0, 0, 6, 7, 0}
        };

        int startNode = 0;
        int endNode = 4;

        List<Integer> shortestPath = findShortestPath(graph, startNode, endNode);

        System.out.println("Shortest path from " + startNode + " to " + endNode + ": " + shortestPath);
    }
}
