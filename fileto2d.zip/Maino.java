import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Maino {
    public static int[][] readGraphFromFile(String fileName) {
        try {
            File file = new File(fileName);
            Scanner scanner = new Scanner(file);


            int n = scanner.nextInt();
            int m = scanner.nextInt();


            int[][] graph = new int[n+1][n+1];


            for (int i = 0; i < m; i++) {
                int source = scanner.nextInt();
                int destination = scanner.nextInt();
                int weight = scanner.nextInt();

                graph[source-1][destination-1] = weight;
                graph[destination-1][source-1] = weight;
            }

            return graph;

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static void printGraph(int[][] graph) {
        if (graph == null) {
            System.out.println("Graph is null.");
            return;
        }

        for (int i = 0; i < graph.length-1; i++) {
            for (int j = 0; j < graph.length-1; j++) {
                System.out.print(graph[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        String fileName = "C:\\Users\\Vaziri\\IdeaProjects\\untitled\\src\\com\\graph.txt";
        int[][] graph = readGraphFromFile(fileName);

        printGraph(graph);
    }
}
