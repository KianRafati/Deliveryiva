import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class GraphVisualization extends Application {

    private static final int NODE_RADIUS = 20;

    private int[][] graph;
    private List<Integer> path;

    public GraphVisualization(int[][] graph, List<Integer> path) {
        this.graph = graph;
        this.path = path;
    }

    @Override
    public void start(Stage primaryStage) {
        Pane pane = new Pane();


        for (int i = 0; i < graph.length; i++) {
            double centerX = NODE_RADIUS + i * NODE_RADIUS * 3;
            double centerY = NODE_RADIUS + i * NODE_RADIUS * 3;
            Circle circle = new Circle(centerX, centerY, NODE_RADIUS);
            circle.setFill(Color.WHITE);
            circle.setStroke(Color.BLACK);
            pane.getChildren().add(circle);
        }


        for (int i = 0; i < graph.length; i++) {
            for (int j = i + 1; j < graph.length; j++) {
                if (graph[i][j] > 0) {
                    double startX = NODE_RADIUS + i * NODE_RADIUS * 3;
                    double startY = NODE_RADIUS + i * NODE_RADIUS * 3;
                    double endX = NODE_RADIUS + j * NODE_RADIUS * 3;
                    double endY = NODE_RADIUS + j * NODE_RADIUS * 3;

                    Line line = new Line(startX, startY, endX, endY);
                    pane.getChildren().add(line);
                }
            }
        }


        for (int i = 0; i < path.size() - 1; i++) {
            int nodeA = path.get(i);
            int nodeB = path.get(i + 1);

            double startX = NODE_RADIUS + nodeA * NODE_RADIUS * 3;
            double startY = NODE_RADIUS + nodeA * NODE_RADIUS * 3;
            double endX = NODE_RADIUS + nodeB * NODE_RADIUS * 3;
            double endY = NODE_RADIUS + nodeB * NODE_RADIUS * 3;

            Line line = new Line(startX, startY, endX, endY);
            line.setStroke(Color.RED);
            line.setStrokeWidth(3);
            pane.getChildren().add(line);
        }

        Scene scene = new Scene(pane, NODE_RADIUS * graph.length * 3, NODE_RADIUS * graph.length * 3);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Graph Visualization");
        primaryStage.show();
    }

    public static void main(String[] args) {

        int[][] graph = {
                {0, 2, 0, 4},
                {2, 0, 1, 0},
                {0, 1, 0, 3},
                {4, 0, 3, 0}
        };

        List<Integer> path = new ArrayList<>();
        path.add(0);
        path.add(1);
        path.add(2);
        path.add(3);

        launch(args);
    }
}

